package com.example.citiesapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
